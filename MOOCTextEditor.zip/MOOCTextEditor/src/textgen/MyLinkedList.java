package textgen;

import java.util.AbstractList;


/** A class that implements a doubly linked list
 * 
 * @author UC San Diego Intermediate Programming MOOC team
 *
 * @param <E> The type of the elements stored in the list
 */
public class MyLinkedList<E> extends AbstractList<E> {
	LLNode<E> head;
	LLNode<E> tail;
	int size;

	/** Create a new empty LinkedList */
	public MyLinkedList() {
		size=0;
		head=new LLNode<E>(null);
		tail=new LLNode<E>(null);
		head.next=tail;
		tail.prev=head;
		// TODO: Implement this method
	}

	/**
	 * Appends an element to the end of the list
	 * @param element The element to add
	 */
	public boolean add(E element ) 
	{
		// TODO: Implement this method
		/*LLNode<E> n=new LLNode<E>(element);
		LLNode<E> t=new LLNode<E>(null);
		t=head;
		for(int i=0;i<size;i++)
		{
			if(t.next==tail)
			{
				n.next=tail;
				n.prev=t;
				t.next=n;
				tail.prev=n;
				size+=1;
				return true;
			}
			else
				t=t.next;
		}
		return false;*/
		add(this.size(), element);
	    
	    return true;
	}

	/** Get the element at position index 
	 * @throws IndexOutOfBoundsException if the index is out of bounds. */
	public E get(int index) 
	{
		if (index < 0 || index > size - 1 || size == 0) {
		      throw new IndexOutOfBoundsException("Index out of bounds in get() method");
		    }
		/*LLNode<E> t=head;
		// TODO: Implement this method.
		for(int i=0;i<size;i++)
		{
			if(index==i)
			{
				return t.data;
			}
			else t=t.next;
		}
		return null;*/
		LLNode<E> node = head.next;
	    for (int i = 0; i < index; i++) {
	      node = node.next;
	    }

	    return node.data;
	}

	/**
	 * Add an element to the list at the specified index
	 * @param The index where the element should be added
	 * @param element The element to add
	 */
	public void add(int index, E element ) 
	{
		if (element == null) {
		      throw new NullPointerException("'Data can not be null!");
		    }

		    // Check if index is within allowed range
		    if (index < 0 || index > size) {
		      throw new IndexOutOfBoundsException("Index out of bounds in 'add at index'");
		    }
		/*LLNode<E> n=new LLNode<E>(element);
		LLNode<E> t=head;
		// TODO: Implement this method.
		for(int i=0;i<size;i++)
		{
			if(index==i)
			{
				n.next=t;
				n.prev=t.prev;
				t.prev.next=n;
				t.prev=n;
				this.size+=1;
			}
			else t=t.next;
		}*/
		    LLNode<E> currentNode = head;
		    LLNode<E> newNode = new LLNode<E>(element);
		    for (int i=0; i < index; i++) {
		      currentNode= currentNode.next;
		    }
		    
		    newNode.prev = currentNode;
		    newNode.next = currentNode.next;
		    newNode.next.prev = newNode;
		    currentNode.next = newNode;
		    
		    this.size++;
		// TODO: Implement this method
	}


	/** Return the size of the list */
	public int size() 
	{
		
		// TODO: Implement this method
		return this.size;
	}

	/** Remove a node at the specified index and return its data element.
	 * @param index The index of the element to remove
	 * @return The data element removed
	 * @throws IndexOutOfBoundsException If index is outside the bounds of the list
	 * 
	 */
	public E remove(int index) 
	{
		if (index < 0 || index > this.size() - 1) {
		      throw new IndexOutOfBoundsException("Illegal index in remove() method.");
		    }
		// TODO: Implement this method
		//LLNode<E> n=new LLNode<E>(element);
		/*LLNode<E> t=head;
		// TODO: Implement this method.
		for(int i=0;i<size;i++)
		{
			if(index==i)
			{
				t.next.prev=t.prev;
				t.prev.next=t.next;
				E d=t.data;
				this.size-=1;
				t=null;
				return d;
			}
			else t=t.next;
		}
		return null;*/
		LLNode<E> nodeToRemove = head.next;
	    for (int i = 0; i < index; i++) {
	      nodeToRemove = nodeToRemove.next;
	    }
		 E removedElement = nodeToRemove.data;
		    nodeToRemove.prev.next = nodeToRemove.next;
		    nodeToRemove.next.prev = nodeToRemove.prev;
		    nodeToRemove.prev = null;
		    nodeToRemove.next = null;
		    
		    this.size--;
		    
		    return removedElement;
	}

	/**
	 * Set an index position in the list to a new element
	 * @param index The index of the element to change
	 * @param element The new element
	 * @return The element that was replaced
	 * @throws IndexOutOfBoundsException if the index is out of bounds.
	 */
	public E set(int index, E element) 
	{
		 if (element == null) {
		      throw new NullPointerException("'Data can not be null!");
		    }
		    
		    if (index < 0 || index > this.size() - 1) {
		      throw new IndexOutOfBoundsException("Index cannot be < 0 or > size minus 1");
		    }
		/*LLNode<E> t;
		t=head;
		// TODO: Implement this method.
		for(int i=0;i<size;i++)
		{
			if(index==i)
			{
				E d=t.data;
				t.data=element;
				return d;
			}
			else t=t.next;
		}
		return null;*/
		    LLNode<E> nodeToSet = head.next;
		    for (int i = 0; i < index; i++) {
		      nodeToSet = nodeToSet.next;
		    }
		    
		    E old = nodeToSet.data;
		    nodeToSet.data = element;

		    return old;
	}   
}

class LLNode<E> 
{
	LLNode<E> prev;
	LLNode<E> next;
	E data;

	// TODO: Add any other methods you think are useful here
	// E.g. you might want to add another constructor

	public LLNode(E e) 
	{
		this.data = e;
		this.prev = null;
		this.next = null;
	}

}
